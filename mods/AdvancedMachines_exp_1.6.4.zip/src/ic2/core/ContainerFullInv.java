package ic2.core;

import ic2.core.ContainerBase;

public abstract class ContainerFullInv extends ContainerBase
{

    public ContainerFullInv(net.minecraft.entity.player.EntityPlayer entityPlayer, ic2.core.block.TileEntityInventory base, int height)
    {
        super(base);
        // TODO Auto-generated constructor stub
    }

}
