package ic2.core.block.machine.tileentity;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;

public class TileEntityCompressor extends TileEntityStandardMachine
{
    
    public TileEntityCompressor()
    {
        super(2, 400, 1);
    }
    
    public GuiScreen getGui(EntityPlayer arg0, boolean arg1)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getInvName()
    {
        // TODO Auto-generated method stub
        return null;
    }

}
