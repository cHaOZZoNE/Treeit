package ic2.core.block;

import net.minecraft.tileentity.TileEntity;

public class TileEntityBlock extends TileEntity
{
    
    public boolean getActive()
    {
        return false;
    }
    
    public short getFacing()
    {
        return 0;
    }
    
    public void setFacing(short x)
    {
        
    }
}
